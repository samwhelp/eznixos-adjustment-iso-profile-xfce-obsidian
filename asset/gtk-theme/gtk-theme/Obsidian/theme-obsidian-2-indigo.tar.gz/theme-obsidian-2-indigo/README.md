# Obsidian 2
Gnome theme (gtk 3.22), based upon Adwaita-Maia dark skin

![alt tag](https://github.com/madmaxms/theme-obsidian-2/blob/indigo/screenshot.jpg)

# Compatibility
Compatible with Gtk 3.22. 
For Cinnamon 3.2 and older versions of gtk (3.18 and below), use the predecessor `Obsidian 1`: 
https://github.com/madmaxms/theme-obsidian-1

# Installation
Clone or download the repo and move the containing folder `Obsidian-2` to your `~/.themes` directory, or to `/usr/share/themes` (needs root access).
