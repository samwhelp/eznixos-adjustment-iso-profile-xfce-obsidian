# Obsidian 2 green
Green edition of Obsidian-2 theme.

![alt tag](https://github.com/madmaxms/theme-obsidian-2/blob/green/screenshot.jpg)

# Compatibility
Compatible with Gtk 3.22. 

# Installation
Clone or download the repo and move the containing folder `Obsidian-2-green` to your `~/.themes` directory, or to `/usr/share/themes` (needs root access).
